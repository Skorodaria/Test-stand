import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import static io.restassured.RestAssured.given;

public class LoadTest extends AbstractTest {

    @BeforeAll
    static void setUp() {

        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();

    }

    @Test
    void getRequestLogTest() {
        given()

                .queryParam("GB202301271f47", "GB202301271f47")
                .log().method()
                .log().params()
                .when()
                .get("https://test-stand.gb.ru/api/posts?owner=notMe&sort=createdAt&order=ASC&page");

        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++=");

        given()

                .queryParam("689644цвв", "ичрприт")
                .log().all()
                .when()
                .get("https://test-stand.gb.ru/api/posts?owner=notMe&sort=createdAt&order=ASC&page");
    }



    @Test
    void getErrorTest() {
        given()
                .queryParam("owner", getowner())
                .queryParam("sort", "false")
                .when()
                .get("https://test-stand.gb.ru/api/posts?owner=notMe&sort=createdAt&order=ASC&page")
                .then().statusCode(201);
    }

    private Object getowner() {
        return null;
    }

    @AfterEach
    void tearDown() {
        given()
                .queryParam("page", "3")
                .delete("https://test-stand.gb.ru/api/posts?owner=notMe&sort=createdAt&order=ASC&page" + id)
                .then()
                .statusCode(200);
    }
    @Test
    void getRequestLogTest() {
        given()

                .queryParam("page", "546")
                .log().method()
                .log().params()
                .when()
                .get("https://test-stand.gb.ru/api/posts?owner=notMe&sort=createdAt&order=ASC&page");

        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++=");

        given()

                .queryParam("order", "")
                .log().all()
                .when()
                .get("https://test-stand.gb.ru/api/posts?owner=notMe&sort=createdAt&order=ASC&page");
    }



    @Test
    void getErrorTest() {
        given()

                .queryParam("owner", "Notme")
                .when()
                .get("https://test-stand.gb.ru/api/posts?owner=notMe&sort=createdAt&order=ASC&page")
                .then().statusCode(201);
    }

    @AfterEach
    void tearDown() {
        given()
                .queryParam("hash", "a3da66460bfb7e62ea1c96cfa0b7a634a346ccbf")
                .delete("https://test-stand.gb.ru/api/posts?sort=createdAt&order=ASC&page=1" + id)
                .then()
                .statusCode(200);
    }
}



import org.junit.Test;

public class StandGb extends AbstractTest {


    @Test
    public void ValidLoginPositiveTest() {
        given()

                .when().contentType("application/x-www-form-urlencoded")
                .formParam("GB202301271f47", "d885669b8b")
                .post(AbstractTest.getBaseUrl())
                .then()
                .statusCode(200);
    }

    @Test
    public void InvalidLoginNegativeTest() {
        given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("34658fhfghxvg", "5566788")
                .post(AbstractTest.getBaseUrl())
                .then()
                .statusCode(401);
    }

    @Test
    public void NullNegativeTest() {
        Object AbstractTest;
        given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("", "")
                .post(AbstractTest.getBaseUrl())
                .when
                .post(AbstractTest.getBaseUrl())
                .then()
                .statusCode(401);


    }
}


